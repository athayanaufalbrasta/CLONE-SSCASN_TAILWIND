import Hero from "../component/hero";
import About from "../component/about";
import Service from "../component/service";

const Home = () => {
  return (
    <>
      <Hero />
      <Service />
      <About />
    </>
  );
};
export default Home;
