import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Nav from "./component/navbar";
import Scrool from "./component/scroolTop";
import Footer from "./component/footer";
import Error from "./component/error";
import Home from "./pages/Home";
import Alur from "./pages/Alur";
import DasarHukum from "./pages/Dasar-Hukum";
import BukuPetunjuk from "./pages/Buku-Petunjuk";
import Login from "./pages/Login";
import Register from "./pages/Register";
import "./style/animation.css";

function App() {
	return (
		<Router>
			<Nav />
			<Routes>
				<Route path="/" Component={Home} />
				<Route path="/alur" Component={Alur} />
				<Route path="/dasar-hukum" Component={DasarHukum} />
				<Route path="/buku-petunjuk" Component={BukuPetunjuk} />
				<Route path="/login" Component={Login} />
				<Route path="/register" Component={Register} />
				<Route path="*" Component={Error} />
			</Routes>
			<Scrool />
			<Footer />
		</Router>
	);
}

export default App;
