import HeroLogo from "../assets/hero.webp";
import { Link } from "react-router-dom";

export default function Hero() {
  return (
    <section className="w-screen px-5 lg:px-20">
      <div className="container mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-10 mb-5 md:py-8 ">
          <div className="slideRight flex flex-col gap-4 pt-10">
            <h1 className="text-blue-600 text-4xl font-bold">Selamat Datang di Portal ASN Karier!</h1>
            <p>
              Portal ASN Karier merupakan portal informasi untuk Calon Aparatur Sipil Negara Indonesia. Temukan lowongan
              formasi terbaru dari instansi pemerintah di seluruh Indonesia. Mudah, transparan, dan informatif.
            </p>
            <p className="text-red-500">Data formasi yang tersedia merupakan Data Formasi TA 2023.</p>
            <Link to={'/dasar-hukum'}>
              <button className="slide w-1/2 md:mt-10 bg-blue-600 rounded-md py-2 text-white font-bold">
                Dasar Hukum
              </button>
            </Link>
          </div>
          <div className="slideLeft col-md-6">
            <img src={HeroLogo} className="" alt="" />
          </div>
        </div>
      </div>
    </section>
  );
}
